package com.honaf.mvvm

import android.app.Application

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}