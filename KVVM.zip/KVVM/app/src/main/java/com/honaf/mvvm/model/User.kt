package com.honaf.mvvm.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "user")
class User {
    @PrimaryKey()
    @ColumnInfo(name = "id", typeAffinity = ColumnInfo.INTEGER)
    var id: Int = 0

    @ColumnInfo(name = "name", typeAffinity = ColumnInfo.TEXT)
    var name: String? = null

    @ColumnInfo(name = "avatar", typeAffinity = ColumnInfo.TEXT)
    @SerializedName("avatar-url")
    var avatar: String = ""

    @ColumnInfo(name = "followers",typeAffinity = ColumnInfo.INTEGER)
    var followers: Int = 0

    @ColumnInfo(name = "following",typeAffinity = ColumnInfo.INTEGER)
    var following: Int = 0

    @ColumnInfo(name = "blog",typeAffinity = ColumnInfo.TEXT)
    var blog: String = ""

    @ColumnInfo(name = "company",typeAffinity = ColumnInfo.TEXT)
    var company: String = ""

    @ColumnInfo(name = "bio",typeAffinity = ColumnInfo.TEXT)
    var bio: String = ""
}