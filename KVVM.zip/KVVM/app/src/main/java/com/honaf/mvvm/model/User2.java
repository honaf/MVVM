package com.honaf.mvvm.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user")
class User2(
    @field:ColumnInfo(
        name = "id",
        typeAffinity = ColumnInfo.INTEGER
    ) @field:PrimaryKey var id: Int, @field:ColumnInfo(
        name = "name",
        typeAffinity = ColumnInfo.TEXT
    ) var name: String
) 